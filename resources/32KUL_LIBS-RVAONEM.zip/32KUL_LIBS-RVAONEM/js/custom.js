import "../css/index.css";

(function () {
  "use strict";

  var app = angular.module("viewCustom", ["angularLoad"]);
})();
